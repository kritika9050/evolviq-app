# EvolvIQ Streamlit Cloud Demo

This is a simplified deployment-ready Streamlit version of EvolvIQ.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy

Upload these files to GitHub and deploy on Streamlit Community Cloud:

- app.py
- requirements.txt
- README.md
