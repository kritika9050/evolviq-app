import streamlit as st
import pandas as pd
from datetime import datetime

st.set_page_config(page_title="EvolvIQ", layout="wide")

if "knowledge" not in st.session_state:
    st.session_state.knowledge = []
if "memory" not in st.session_state:
    st.session_state.memory = []
if "graph_edges" not in st.session_state:
    st.session_state.graph_edges = []

st.title("EvolvIQ — AI-Native Intelligence Workspace")
st.caption("Research Mode + Knowledge-Augmented Chat + Memory + Knowledge Graph")

mode = st.sidebar.radio(
    "Choose workflow",
    ["Research Mode", "Knowledge Chat", "Upload Knowledge", "Knowledge Graph", "Memory", "Knowledge Base"]
)

def seed_research(topic):
    items = [
        ("fact", f"{topic} studies how psychological factors influence decision-making."),
        ("fact", "Daniel Kahneman and Amos Tversky contributed significantly to behavioral economics."),
        ("fact", "Prospect Theory explains decision-making under risk and uncertainty."),
        ("fact", "Loss aversion suggests people feel losses more strongly than equivalent gains."),
        ("insight", "Behavioral economics connects psychology, economics, policy design, and product decisions."),
        ("insight", "Default choices and framing can influence user behavior."),
    ]
    for t, text in items:
        st.session_state.knowledge.append({
            "type": t,
            "text": text,
            "confidence": "High" if t == "fact" else "Medium",
            "evidence": f"Autonomous research synthesis for topic: {topic}",
            "created_at": datetime.now().isoformat(timespec="seconds")
        })
    st.session_state.memory.append({
        "memory_type": "stable_topic_summary",
        "text": f"The workspace has accumulated structured knowledge about {topic}.",
        "status": "active",
        "updated_at": datetime.now().isoformat(timespec="seconds")
    })
    edges = [
        (topic, "MENTIONS", "Daniel Kahneman"),
        (topic, "MENTIONS", "Amos Tversky"),
        (topic, "HAS_CONCEPT", "Prospect Theory"),
        ("Loss Aversion", "RELATED_TO", "Prospect Theory"),
        ("Default Effect", "INFLUENCES", "User Choice"),
        ("Behavioral Economics", "APPLIED_TO", "Policy Design"),
    ]
    st.session_state.graph_edges.extend(edges)

if mode == "Research Mode":
    st.header("Autonomous Research Mode")
    topic = st.text_input("Enter topic", "Behavioral Economics")
    max_sources = st.slider("Max sources", 1, 5, 3)
    if st.button("Start Research"):
        seed_research(topic)
        st.success("Research complete")
        col1, col2 = st.columns(2)
        col1.metric("Sources gathered", max_sources)
        col2.metric("Knowledge created", 6)
        st.subheader("Synthesis")
        st.json({
            "summary": f"Research on {topic} created structured knowledge, memory, and graph relationships.",
            "key_points": [
                f"{topic} connects psychology and decision-making.",
                "Prospect Theory and loss aversion are central concepts.",
                "Knowledge graph and memory were updated.",
            ],
            "confidence": "Medium to High",
            "evolution": "No major contradiction detected in this run."
        })

elif mode == "Knowledge Chat":
    st.header("Knowledge-Augmented Chat")
    q = st.text_input("Ask a question", "What do we know about Behavioral Economics?")
    if st.button("Ask"):
        relevant = st.session_state.knowledge[:5]
        if not relevant:
            st.warning("No stored knowledge found. Run Research Mode first.")
        else:
            st.subheader("Answer based on stored knowledge")
            for item in relevant:
                st.write(f"- {item['text']}")
            st.subheader("Evidence trace")
            for item in relevant[:3]:
                st.write(f"- {item['evidence']}")
            st.subheader("Confidence")
            st.write("High — based on stored knowledge and evidence.")

elif mode == "Upload Knowledge":
    st.header("Upload Knowledge")
    file = st.file_uploader("Upload TXT file", type=["txt"])
    if file:
        text = file.read().decode("utf-8", errors="ignore")
        chunks = [x.strip() for x in text.split(".") if len(x.strip()) > 20]
        created = 0
        for chunk in chunks[:10]:
            st.session_state.knowledge.append({
                "type": "uploaded_fact",
                "text": chunk + ".",
                "confidence": "Medium",
                "evidence": f"Uploaded file: {file.name}",
                "created_at": datetime.now().isoformat(timespec="seconds")
            })
            created += 1
        st.session_state.memory.append({
            "memory_type": "incremental_update",
            "text": f"Uploaded file {file.name} added {created} new knowledge items.",
            "status": "active",
            "updated_at": datetime.now().isoformat(timespec="seconds")
        })
        st.session_state.graph_edges.append(("Uploaded Knowledge", "UPDATES", "Knowledge Base"))
        st.success("Upload processed and knowledge updated")
        st.json({
            "filename": file.name,
            "knowledge_items": created,
            "evolution": "New information added incrementally.",
            "contradictions": "Potential contradictions would be flagged for review."
        })

elif mode == "Knowledge Graph":
    st.header("Knowledge Graph Summary")
    nodes = set()
    for s, r, t in st.session_state.graph_edges:
        nodes.add(s); nodes.add(t)
    col1, col2 = st.columns(2)
    col1.metric("Nodes", len(nodes))
    col2.metric("Edges", len(st.session_state.graph_edges))
    if st.session_state.graph_edges:
        df = pd.DataFrame(st.session_state.graph_edges, columns=["source", "relation", "target"])
        st.dataframe(df, use_container_width=True)
    else:
        st.info("No graph relationships yet. Run Research Mode first.")

elif mode == "Memory":
    st.header("Memory")
    if st.session_state.memory:
        st.dataframe(pd.DataFrame(st.session_state.memory), use_container_width=True)
    else:
        st.info("No memory yet. Run Research Mode first.")

elif mode == "Knowledge Base":
    st.header("Knowledge Base")
    if st.session_state.knowledge:
        st.dataframe(pd.DataFrame(st.session_state.knowledge), use_container_width=True)
    else:
        st.info("No knowledge yet. Run Research Mode first.")